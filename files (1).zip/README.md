# AMES Building Construction Company — Website

A modern, fully responsive marketing site built with plain HTML5, CSS3 and vanilla JavaScript — no frameworks or build step required.

## Folder structure

```
AMES-Construction/
├── index.html
├── css/
│   ├── style.css        # design tokens, layout, components
│   ├── responsive.css    # tablet / mobile breakpoints
│   └── animations.css    # keyframes, reveal-on-scroll
├── js/
│   ├── main.js           # nav, header state, FAQ, forms, scroll reveal
│   ├── slider.js         # testimonial slider
│   ├── gallery.js        # project grid + gallery data/rendering
│   └── counter.js        # animated statistics counters
├── images/                # add your own photography here (see below)
└── README.md
```

## Running it locally

No build tools needed. Either:

- Double-click `index.html` to open it directly in a browser, or
- Serve it locally for the most accurate preview:
  ```bash
  cd AMES-Construction
  python3 -m http.server 8000
  ```
  then open `http://localhost:8000`.

## Design notes

- **Palette**: Construction Red `#C62828`, Dark Charcoal `#212121`, White `#FFFFFF`, Light Gray `#F5F5F5`, Gold `#FFC107` accent.
- **Type**: Poppins for headings, Open Sans for body text (loaded from Google Fonts).
- **Icons**: Font Awesome 6 (loaded from cdnjs).
- Visuals are hand-built line-art SVGs (blueprint grid, hazard stripes, project glyphs) instead of stock photography, so the site has no licensing dependencies out of the box and loads instantly.

## Adding your own photography

Every visual panel (hero background, project thumbnails, gallery tiles, blog thumbnails) currently uses an inline SVG placeholder so the template is copyright-clean. To swap in real photos:

1. Drop your images into `images/` (suggested subfolders: `hero/`, `projects/`, `team/`, `testimonials/`, `icons/`).
2. In `index.html` / `js/gallery.js`, replace the relevant `<svg>...</svg>` block with an `<img src="images/your-file.jpg" alt="...">`.
3. Re-check contrast: text overlaid on photos may need a darker gradient overlay — see `.project-thumb` and `.blog-thumb` in `style.css` for the existing overlay pattern to extend.

## Customizing content

- **Company info, team, testimonials, blog posts, projects**: edit the arrays/markup directly in `index.html`, `js/slider.js`, and `js/gallery.js`.
- **Colors/fonts**: all defined once as CSS custom properties at the top of `css/style.css` under `:root`.
- **Contact form**: `js/main.js` currently validates and shows a success message client-side only. To actually receive submissions, point the `<form>` at a backend endpoint or a form service (e.g. Formspree, Netlify Forms) and replace the `preventDefault` handler with a real `fetch` POST.

## Deployment

### GitHub Pages
1. Push this folder to a GitHub repository.
2. Repository Settings → Pages → set source to the `main` branch, root folder.
3. Your site will be live at `https://<username>.github.io/<repo>/`.

### Netlify / Vercel
1. Drag and drop the `AMES-Construction` folder onto the Netlify or Vercel dashboard, or connect the GitHub repo.
2. No build command is required — this is a static site.

## Before going to production

- Replace placeholder phone/email/address in the Contact and Footer sections.
- Swap SVG placeholders for real photography and optimize images (WebP, appropriate dimensions) for faster loading.
- Wire the contact and newsletter forms to a real backend or form service.
- Run a Lighthouse audit and an HTML validator pass before launch.
