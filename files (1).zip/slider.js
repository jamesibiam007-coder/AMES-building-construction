/* =========================================================
   SLIDER.JS — testimonial slider
   ========================================================= */

document.addEventListener('DOMContentLoaded', () => {

  const testimonials = [
    {
      name: 'Priya Chandran',
      company: 'Homeowner, Millbrook',
      rating: 5,
      quote: 'AMES rebuilt our foundation and added a second story without a single missed deadline. Every inspection was scheduled before we even asked.'
    },
    {
      name: 'Marcus Webb',
      company: 'Owner, Webb Retail Group',
      rating: 5,
      quote: 'Three retail build-outs with AMES so far. The quotes have matched the final invoice every time, which is rarer than it should be in this industry.'
    },
    {
      name: 'Fatima Al-Rashid',
      company: 'Facilities Director, Northbridge Clinic',
      rating: 5,
      quote: 'Our clinic expansion had a hard opening date tied to a lease. AMES built in buffer for permitting delays and still finished a week early.'
    },
    {
      name: 'Daniel Osei',
      company: 'Homeowner, Riverside',
      rating: 4,
      quote: 'Communication was excellent throughout our kitchen and structural renovation. The only hiccup was a supplier delay outside their control, and they adjusted the schedule fast.'
    }
  ];

  const track = document.getElementById('testimonialTrack');
  const dotsWrap = document.getElementById('sliderDots');
  if (!track) return;

  let current = 0;

  const starString = (rating) => {
    let s = '';
    for (let i = 0; i < 5; i++) s += i < rating ? '★' : '☆';
    return s;
  };

  testimonials.forEach((t) => {
    const slide = document.createElement('div');
    slide.className = 'testimonial-slide';
    slide.innerHTML = `
      <div class="stars" aria-hidden="true">${starString(t.rating)}</div>
      <blockquote>&ldquo;${t.quote}&rdquo;</blockquote>
      <div class="testimonial-avatar">${t.name.split(' ').map(n => n[0]).join('')}</div>
      <h4>${t.name}</h4>
      <span>${t.company}</span>
    `;
    track.appendChild(slide);
  });

  testimonials.forEach((_, i) => {
    const dot = document.createElement('button');
    dot.setAttribute('aria-label', `Go to testimonial ${i + 1}`);
    if (i === 0) dot.classList.add('active');
    dot.addEventListener('click', () => goTo(i));
    dotsWrap.appendChild(dot);
  });

  function goTo(index) {
    current = (index + testimonials.length) % testimonials.length;
    track.style.transform = `translateX(-${current * 100}%)`;
    dotsWrap.querySelectorAll('button').forEach((d, i) => d.classList.toggle('active', i === current));
  }

  document.getElementById('sliderPrev').addEventListener('click', () => goTo(current - 1));
  document.getElementById('sliderNext').addEventListener('click', () => goTo(current + 1));

  let autoplay = setInterval(() => goTo(current + 1), 6000);
  const sliderEl = document.getElementById('testimonialSlider');
  sliderEl.addEventListener('mouseenter', () => clearInterval(autoplay));
  sliderEl.addEventListener('mouseleave', () => { autoplay = setInterval(() => goTo(current + 1), 6000); });

});
