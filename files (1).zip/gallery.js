/* =========================================================
   GALLERY.JS — featured projects + site gallery
   Uses generated line-art SVG thumbnails (no stock photos)
   so every project card renders instantly and license-free.
   ========================================================= */

document.addEventListener('DOMContentLoaded', () => {

  const projects = [
    { title: 'Oakhaven Residence', category: 'residential', label: 'Residential', location: 'Millbrook', year: '2025', glyph: 'house' },
    { title: 'Northbridge Clinic Expansion', category: 'commercial', label: 'Commercial', location: 'Northbridge', year: '2025', glyph: 'building' },
    { title: 'Route 9 Resurfacing', category: 'road', label: 'Road', location: 'County Route 9', year: '2024', glyph: 'road' },
    { title: 'Webb Retail Flagship', category: 'commercial', label: 'Commercial', location: 'Downtown Millbrook', year: '2024', glyph: 'building' },
    { title: 'Riverside Loft Renovation', category: 'renovation', label: 'Renovation', location: 'Riverside', year: '2024', glyph: 'renovate' },
    { title: 'Cedar Grove Townhomes', category: 'residential', label: 'Residential', location: 'Cedar Grove', year: '2023', glyph: 'house' },
  ];

  const glyphs = {
    house: `<polygon points="30,60 30,110 90,110 90,60" fill="none" stroke="#FFC107" stroke-width="2"/><polygon points="20,60 60,30 100,60" fill="none" stroke="#FFC107" stroke-width="2"/><rect x="50" y="80" width="18" height="30" fill="none" stroke="#F5F5F5" stroke-width="1.5"/>`,
    building: `<rect x="35" y="20" width="50" height="90" fill="none" stroke="#FFC107" stroke-width="2"/><line x1="35" y1="40" x2="85" y2="40" stroke="#F5F5F5" stroke-width="1"/><line x1="35" y1="60" x2="85" y2="60" stroke="#F5F5F5" stroke-width="1"/><line x1="35" y1="80" x2="85" y2="80" stroke="#F5F5F5" stroke-width="1"/><line x1="55" y1="20" x2="55" y2="110" stroke="#F5F5F5" stroke-width="1"/>`,
    road: `<line x1="10" y1="110" x2="60" y2="20" stroke="#FFC107" stroke-width="2"/><line x1="110" y1="110" x2="60" y2="20" stroke="#FFC107" stroke-width="2"/><line x1="60" y1="30" x2="60" y2="45" stroke="#F5F5F5" stroke-width="2"/><line x1="60" y1="60" x2="60" y2="75" stroke="#F5F5F5" stroke-width="2"/><line x1="60" y1="90" x2="60" y2="105" stroke="#F5F5F5" stroke-width="2"/>`,
    renovate: `<rect x="30" y="35" width="60" height="65" fill="none" stroke="#FFC107" stroke-width="2"/><line x1="30" y1="60" x2="90" y2="60" stroke="#F5F5F5" stroke-width="1"/><path d="M70 20 L80 30 L60 50 L50 40 Z" fill="none" stroke="#C62828" stroke-width="2"/>`
  };

  const gridWrap = document.getElementById('projectGrid');
  projects.forEach((p) => {
    const card = document.createElement('article');
    card.className = 'project-card';
    card.dataset.category = p.category;
    card.innerHTML = `
      <div class="project-thumb">
        <svg viewBox="0 0 120 130" xmlns="http://www.w3.org/2000/svg">
          <rect width="120" height="130" fill="#212121"/>
          ${glyphs[p.glyph]}
        </svg>
        <span class="project-cat">${p.label}</span>
      </div>
      <div class="project-body">
        <h3>${p.title}</h3>
        <div class="project-meta"><span>${p.location}</span><span>${p.year}</span></div>
      </div>
    `;
    gridWrap.appendChild(card);
  });

  /* ---- Site gallery grid ---- */
  const galleryItems = [
    { glyph: 'house', label: 'Framing on site', size: 'tall' },
    { glyph: 'building', label: 'Steel erection', size: '' },
    { glyph: 'road', label: 'Grading crew', size: 'wide' },
    { glyph: 'renovate', label: 'Interior demo', size: '' },
    { glyph: 'house', label: 'Foundation pour', size: '' },
    { glyph: 'building', label: 'Curtain wall install', size: 'tall' },
    { glyph: 'road', label: 'Asphalt finishing', size: '' },
  ];

  const galleryWrap = document.getElementById('galleryGrid');
  galleryItems.forEach((g) => {
    const item = document.createElement('div');
    item.className = `gallery-item ${g.size}`.trim();
    item.innerHTML = `
      <svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice">
        <rect width="120" height="120" fill="#2C2C2A"/>
        ${glyphs[g.glyph]}
      </svg>
      <div class="gallery-caption">${g.label}</div>
    `;
    galleryWrap.appendChild(item);
  });

});
